#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      john.f.kennedy
#
# Created:     30/01/2022
# Copyright:   (c) john.f.kennedy 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import arcpy
import os
from time import time, localtime, strftime, sleep, gmtime

def unique_values(table, field):  ##uses list comprehension
    with arcpy.da.SearchCursor(table, [field]) as cursor:
        return sorted({row[0] for row in cursor})


def main():
    try:
        print("main()")
        # Set a start time so that we can see how log things take
        start_time = time()

        # Set Workspace
        arcpy.env.workspace = ProjectGDB
        # Set Scratch Workspace
        arcpy.env.scratchWorkspace = ScratchGDB

        # Start looping over the table_name array as we go region by region.
        for table_name in table_names:
            # Assigning variables from items in the chosen table list
            #region_shape = table_name[0]
            #region_boundary = table_name[1]
            region_abb = table_name[2]
            region = table_name[3]
            csv_file = table_name[4]
            #region_georef = table_name[5]
            #region_contours = table_name[6]

            # Make Geodatabase friendly name
            region_name = region.replace('(','').replace(')','').replace('-','_to_').replace(' ', '_')

            # Write a message to the log file
            msg = "STARTING REGION {0} ON {1}".format(region, strftime("%a %b %d %I:%M:%S %p", localtime()))
            print(msg); del msg

            #print(region)
            #print(region_abb)
            #print(region_name)
            #print(csv_file)

            #Final benchmark for the region.
            msg = "ENDING REGION {} COMPLETED ON {}".format(region, strftime("%a %b %d %I:%M:%S %p", localtime()))
            print(msg); del msg

            # Elapsed time
            end_time = time()
            elapse_time =  end_time - start_time
            msg = u"Elapsed Time {0} (H:M:S)\n".format(strftime("%H:%M:%S", gmtime(elapse_time)))
            print(msg); del msg

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo


if __name__ == '__main__':
    # Use all of the cores on the machine.
    arcpy.env.parallelProcessingFactor = "100%"
    ##!!WARNING!!:::::::SET THE OVERWRITE TO ON - ANY ITEMS THAT GET SAVED WILL BE OVERWRITTEN
    arcpy.env.overwriteOutput = True

    # Project related items
    #Version = "March 2021"
    #DateCode = "20210301"
    Version = "February 2022"
    DateCode = "20220201"
    ProjectName = "DisMap {0}".format(Version)

    BASE_DIRECTORY = os.path.dirname(os.path.realpath(__file__))
    BASE_DIRECTORY = os.path.join(BASE_DIRECTORY, Version)
    # print('BASE_DIRECTORY: ', BASE_DIRECTORY)

    # ###--->>> Software Environment Level
    #SoftwareEnvironmentLevel = ""
    SoftwareEnvironmentLevel = "Dev"
    #SoftwareEnvironmentLevel = "Test"

    ProjectGDB = os.path.join(BASE_DIRECTORY, "{0}.gdb".format(ProjectName + " " + SoftwareEnvironmentLevel))
    ANALYSIS_DIRECTORY = os.path.join(BASE_DIRECTORY, "Analysis Folder {0} {1}".format(Version, SoftwareEnvironmentLevel))
    MOSAIC_DIRECTORY = os.path.join(BASE_DIRECTORY, "Mosaic Folder {0} {1}".format(Version, SoftwareEnvironmentLevel))
    ScratchGDB = os.path.join(BASE_DIRECTORY, "Scratch {0} {1}".format(Version, SoftwareEnvironmentLevel), "scratch.gdb")
    ScratchFolder = os.path.join(BASE_DIRECTORY, "Scratch {0} {1}".format(Version, SoftwareEnvironmentLevel))

    arcpy.env.scratchWorkspace = ScratchGDB

    table_names = [
                   [ 'AI_Shape', 'AI_Boundary','AI', 'Aleutian Islands', 'ai_csv', 'NAD_1983_2011_UTM_Zone_1N', 'contour_ai'],
                   [ 'EBS_Shape', 'EBS_Boundary','EBS', 'Eastern Bering Sea', 'ebs_csv', 'NAD_1983_2011_UTM_Zone_3N', 'contour_ebs'],
                   [ 'GOA_Shape', 'GOA_Boundary','GOA', 'Gulf of Alaska', 'goa_csv', 'NAD_1983_2011_UTM_Zone_5N', 'contour_goa'],

                   [ 'GOM_Shape', 'GOM_Boundary','GOM', 'Gulf of Mexico', 'gmex_csv', 'NAD_1983_2011_UTM_Zone_15N', 'contour_gom'],

                   [ 'NEUS_Fall_Shape', 'NEUS_Fall_Boundary','NEUS_F', 'Northeast US Fall', 'neusf_csv', 'NAD_1983_2011_UTM_Zone_18N', 'contour_neus'],
                   [ 'NEUS_Spring_Shape', 'NEUS_Spring_Boundary','NEUS_S', 'Northeast US Spring', 'neus_csv', 'NAD_1983_2011_UTM_Zone_18N', 'contour_neus'],


                   [ 'SEUS_Shape', 'SEUS_Boundary','SEUS_SPR', 'Southeast US Spring', 'seus_spr_csv', 'NAD_1983_2011_UTM_Zone_17N', 'contour_seus'],
                   [ 'SEUS_Shape', 'SEUS_Boundary','SEUS_SUM', 'Southeast US Summer', 'seus_sum_csv', 'NAD_1983_2011_UTM_Zone_17N', 'contour_seus'],
                   [ 'SEUS_Shape', 'SEUS_Boundary','SEUS_FALL', 'Southeast US Fall', 'seus_fal_csv', 'NAD_1983_2011_UTM_Zone_17N', 'contour_seus'],

                   [ 'WC_Ann_Shape', 'WC_Ann_Boundary','WC_ANN', 'West Coast Annual 2003-Present', 'wcann_csv', 'NAD_1983_2011_UTM_Zone_10N', 'contour_wc'],
                   [ 'WC_Tri_Shape', 'WC_Tri_Boundary','WC_TRI', 'West Coast Triennial 1977-2004', 'wctri_csv', 'NAD_1983_2011_UTM_Zone_10N', 'contour_wc']
                  ]

    # Set to True if we want to filter on certian one or more regions, else
    # False to process all regions
    FilterRegions = True

    # ###--->>> Use a list to filter on regions.
    # Below are lists used to
    # test different regions
    #selected_regions = ['AI', 'EBS', 'GOA', 'GOM', 'NEUS_F', 'NEUS_S', 'SEUS_FALL', 'SEUS_SPR', 'SEUS_SUM', 'WC_ANN', 'WC_TRI',]

    selected_regions = ['AI',]

    # Test if we are filtering on regions. If so, a new table_names list is
    # created with the selected regions remaining in the list
    if FilterRegions:
        # New table_names list of lists #-> https://stackoverflow.com/questions/21507319/python-list-comprehension-list-of-lists
        table_names = [[r for r in group] for group in table_names if group[2] in selected_regions]
    else:
        pass


    main()


##    print(">-> arcpy.management.Compact")
##    arcpy.management.Compact(ProjectGDB)
##    msg = arcpy.GetMessages()
##    msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
##    print(msg); del msg
