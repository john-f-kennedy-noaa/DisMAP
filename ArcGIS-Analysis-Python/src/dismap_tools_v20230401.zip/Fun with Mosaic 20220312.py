#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      john.f.kennedy
#
# Created:     30/01/2022
# Copyright:   (c) john.f.kennedy 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import arcpy
import os

def unique_values(table, field):  ##uses list comprehension
    with arcpy.da.SearchCursor(table, [field]) as cursor:
        return sorted({row[0] for row in cursor})

def analyzeMosaicDataset():
    try:
        print("analyzeMosaicDataset()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            print(">-> arcpy.management.AnalyzeMosaicDataset")
            with arcpy.EnvManager(scratchWorkspace = ScratchGDB, workspace = ProjectGDB):
                arcpy.management.AnalyzeMosaicDataset(region_mosaic,
                                                      '',
                                                      "FOOTPRINT;FUNCTION;RASTER;PATHS;SOURCE_VALIDITY;STALE;STATISTICS;PERFORMANCE;INFORMATION"
                                                     )
            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def calculateCellSizeRanges():
    try:
        print("calculateCellSizeRanges()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            print(">-> arcpy.management.CalculateCellSizeRanges")
            arcpy.management.CalculateCellSizeRanges(region_mosaic,
                                                     "#",
                                                     "MIN_CELL_SIZES",
                                                     "MAX_CELL_SIZES"
                                                    )
            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg


    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def repairMosaicDatasetPaths():
    try:
        print("repairMosaicDatasetPaths()")
        DeleteExportTable = True

        for region_abb in region_abbs:
            print("Region: {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            if arcpy.Exists(region_mosaic):
                print("Mosaic: {0}".format(region_mosaic))
                region_mosaic_export_paths = os.path.join(ProjectGDB, region_abb+'_Export_Paths')

                print(">-> arcpy.management.ExportMosaicDatasetPaths")
                arcpy.management.ExportMosaicDatasetPaths(region_mosaic, region_mosaic_export_paths, "", "BROKEN", "RASTER")
                msg = arcpy.GetMessages()
                msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
                print(msg); del msg

                old_paths = unique_values(region_mosaic_export_paths, "Path")
                old_paths = [p.replace(os.sep, '/') for p in old_paths]

                #print(old_paths)

                names = []
                for old_path in old_paths:
                    print("\t Old: {0}".format(old_path))
                    new_path = old_path.replace('Analysis Folder {0}'.format(Version), 'Analysis Folder {0} {1}'.format(Version, SoftwareEnvironmentLevel))
                    #print("\t New: {0}".format(new_path))
                    if os.path.isfile(new_path):
                        #print("\t New path is missing")
                        print("\t New: {0}".format(new_path))
                        name, ext = os.path.splitext(os.path.basename(old_path))
                        names.append(name)
                        del name, ext
                #print("Name IN ('{0}')".format("', '".join(names)))

                old_and_new_paths = [[old_path, old_path.replace('Analysis Folder {0}', 'Analysis Folder {0} {1}'.format(Version, SoftwareEnvironmentLevel))] for old_path in old_paths]

                if old_and_new_paths:
                    print(">-> arcpy.management.RepairMosaicDatasetPaths")
                    arcpy.management.RepairMosaicDatasetPaths(region_mosaic, old_and_new_paths)
                    msg = arcpy.GetMessages()
                    msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
                    print(msg); del msg

                    #print("Name IN ('{0}')".format("', '".join(names)))
                    print(">-> arcpy.management.SynchronizeMosaicDataset")
                    arcpy.management.SynchronizeMosaicDataset(region_mosaic,
                                                              "Name IN ('{0}')".format("', '".join(names)),
                                                              #"",
                                                              "NO_NEW_ITEMS",
                                                              "SYNC_ALL",
                                                              "UPDATE_CELL_SIZES",
                                                              "UPDATE_BOUNDARY",
                                                              "NO_OVERVIEWS",
                                                              "NO_PYRAMIDS",
                                                              "CALCULATE_STATISTICS",
                                                              "BUILD_THUMBNAILS",
                                                              "NO_ITEM_CACHE",
                                                              "REBUILD_RASTER",
                                                              "UPDATE_FIELDS",
                                                              "CenterX;CenterY;CommonName;CoreSpecies;Dimensions;GroupName;OARegion;ProductName;Raster;Shape;Species;SpeciesCommonName;StdTime;Tag;Variable;Year;ZOrder",
                                                              "UPDATE_EXISTING_ITEMS",
                                                              "REMOVE_BROKEN_ITEMS",
                                                              "OVERWRITE_EXISTING_ITEMS",
                                                              "NO_REFRESH_INFO",
                                                              "ESTIMATE_STATISTICS")
                    #arcpy.management.SynchronizeMosaicDataset("GOA", "Name IN ('GOA_1984_Core_Species_Richness', 'GOA_1984_Species_Richness')", "NO_NEW_ITEMS", "SYNC_STALE", "UPDATE_CELL_SIZES", "UPDATE_BOUNDARY", "NO_OVERVIEWS", "NO_PYRAMIDS", "NO_STATISTICS", "NO_THUMBNAILS", "NO_ITEM_CACHE", "REBUILD_RASTER", "UPDATE_FIELDS", "CenterX;CenterY;CommonName;CoreSpecies;Dimensions;GroupName;OARegion;ProductName;Raster;Shape;Species;SpeciesCommonName;StdTime;Tag;Variable;Year;ZOrder", "UPDATE_EXISTING_ITEMS", "IGNORE_BROKEN_ITEMS", "SKIP_EXISTING_ITEMS", "NO_REFRESH_INFO", "NO_STATISTICS")


                if DeleteExportTable:
                    print(">-> arcpy.Delete_management")
                    arcpy.management.Delete(region_mosaic_export_paths)
                    msg = arcpy.GetMessages()
                    msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
                    print(msg); del msg
            else:
                print("Missing Mosaic: {0}".format(region_mosaic))
    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo


def buildPyramidsandStatistics():
    try:
        print("buildPyramidsandStatistics()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            print(">-> arcpy.management.BuildPyramidsandStatistics")
            with arcpy.EnvManager(scratchWorkspace = ScratchGDB, workspace = ProjectGDB):
                arcpy.management.BuildPyramidsandStatistics(region_mosaic,
                                                            "INCLUDE_SUBDIRECTORIES",
                                                            "NONE",
                                                            "CALCULATE_STATISTICS",
                                                            "BUILD_ON_SOURCE",
                                                            '',
                                                            "ESTIMATE_STATISTICS",
                                                            1,
                                                            1,
                                                            [],
                                                            -1,
                                                            "NONE",
                                                            "NEAREST",
                                                            "DEFAULT",
                                                            75,
                                                            "OVERWRITE",
                                                            '',
                                                            "NONE"
                                                           )
            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def synchronizeMosaicDataset():
    try:
        print("synchronizeMosaicDataset()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            print(">-> arcpy.management.SynchronizeMosaicDataset")
            arcpy.management.SynchronizeMosaicDataset(region_mosaic,
                                                      "",
                                                      "NO_NEW_ITEMS",
                                                      "SYNC_ALL",
                                                      "UPDATE_CELL_SIZES",
                                                      "UPDATE_BOUNDARY",
                                                      "NO_OVERVIEWS",
                                                      "NO_PYRAMIDS",
                                                      "CALCULATE_STATISTICS",
                                                      "BUILD_THUMBNAILS",
                                                      "NO_ITEM_CACHE",
                                                      "REBUILD_RASTER",
                                                      "UPDATE_FIELDS",
                                                      "CenterX;CenterY;CommonName;CoreSpecies;Dimensions;GroupName;OARegion;ProductName;Raster;Shape;Species;SpeciesCommonName;StdTime;Tag;Variable;Year;ZOrder",
                                                      "UPDATE_EXISTING_ITEMS",
                                                      #"REMOVE_BROKEN_ITEMS",
                                                      "IGNORE_BROKEN_ITEMS",
                                                      #"OVERWRITE_EXISTING_ITEMS",
                                                      "SKIP_EXISTING_ITEMS",
                                                      #"NO_REFRESH_INFO",
                                                      "REFRESH_INFO",
                                                      "ESTIMATE_STATISTICS")

##                    arcpy.management.SynchronizeMosaicDataset(r"C:\Users\john.f.kennedy\Documents\GitHub\DisMap\ArcGIS Analysis February 2022\DisMap February 2022 Dev.gdb\AI",
##                    '',
##                    "NO_NEW_ITEMS",
##                    "SYNC_ALL",
##                    "UPDATE_CELL_SIZES",
##                    "UPDATE_BOUNDARY",
##                    "NO_OVERVIEWS",
##                    "NO_PYRAMIDS",
##                    "CALCULATE_STATISTICS",
##                    "BUILD_THUMBNAILS",
##                    "NO_ITEM_CACHE",
##                    "REBUILD_RASTER",
##                    "NO_FIELDS",
##                    "CenterX;CenterY;CommonName;CoreSpecies;Dimensions;GroupName;OARegion;ProductName;Raster;Shape;Species;SpeciesCommonName;StdTime;Tag;Variable;Year;ZOrder",
##                    "UPDATE_EXISTING_ITEMS",
##                    "IGNORE_BROKEN_ITEMS",
##                    "SKIP_EXISTING_ITEMS",
##                    "NO_REFRESH_INFO",
##                    "ESTIMATE_STATISTICS")
            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def setMosaicDatasetProperties():
    try:
        print("setMosaicDatasetProperties()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            variables = unique_values(region_mosaic, "Variable")
            variables = "';'".join(variables)

            print(">-> arcpy.management.SetMosaicDatasetProperties")
            arcpy.management.SetMosaicDatasetProperties(region_mosaic,
                                                        4100,
                                                        15000,
                                                        "None;JPEG;LZ77;LERC",
                                                        "LZ77",
                                                        75,
                                                        0.01,
                                                        "BILINEAR",
                                                        "NOT_CLIP",
                                                        "FOOTPRINTS_MAY_CONTAIN_NODATA",
                                                        "CLIP",
                                                        "NOT_APPLY",
                                                        "Basic",
                                                        "Basic",
                                                        "NorthWest;Center;LockRaster;ByAttribute;Nadir;Viewpoint;Seamline;None",
                                                        "NorthWest",
                                                        '',
                                                        '',
                                                        "ASCENDING",
                                                        "FIRST",
                                                        10,
                                                        600,
                                                        300,
                                                        20,
                                                        0.8,
                                                        "0 0",
                                                        "Basic",
                                                        "Name;MinPS;MaxPS;LowPS;HighPS;Tag;GroupName;ProductName;CenterX;CenterY;ZOrder;Shape_Length;Shape_Area;OARegion;Species;CommonName;SpeciesCommonName;CoreSpecies;Year;Variable;StdTime;Thumbnail;Dimensions",
                                                        "DISABLED",
                                                        '',
                                                        '',
                                                        '',
                                                        None,
                                                        20,
                                                        1000,
                                                        "GENERIC",
                                                        1,
                                                        #"None;'{0}'".format(variables),
                                                        "None",
                                                        "None",
                                                        None,
                                                        '',
                                                        "NONE",
                                                        None)
            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg


    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def calculateField():
    try:
        print("copyRaster()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            print(">-> arcpy.management.MakeMosaicLayer")
            arcpy.management.MakeMosaicLayer(region_mosaic, "{0}_MosaicLayer".format(region_abb), '', "", None, '', '', '', '', "ASCENDING", "FIRST", 2000, "None")

            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg

            print(">-> arcpy.management.CalculateField")
            arcpy.management.CalculateField("{0}_MosaicLayer".format(region_abb), 'Variable', '!Variable!.replace(".","").replace("-"," ").replace("(","").replace(")","").replace("/","and").replace("_"," ")')

            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg

            print(">-> arcpy.management.Delete")
            arcpy.management.Delete("{0}_MosaicLayer".format(region_abb))

            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def buildMultidimensionalInfo():
    try:
        print("copyRaster()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            try:
                print(">-> arcpy.md.BuildMultidimensionalInfo DELETE_MULTIDIMENSIONAL_INFO")

                arcpy.md.BuildMultidimensionalInfo(region_mosaic, '', None, None, "DELETE_MULTIDIMENSIONAL_INFO")
                msg = arcpy.GetMessages()
                msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
                print(msg); del msg

            except:
                pass

            print(">-> arcpy.md.BuildMultidimensionalInfo")

            #arcpy.md.BuildMultidimensionalInfo(region_mosaic, "Variable", "StdTime",)
            arcpy.md.BuildMultidimensionalInfo(region_mosaic, "Variable", "StdTime # #", None, "NO_DELETE_MULTIDIMENSIONAL_INFO")

            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def copyRaster():
    try:
        print("copyRaster()")
        for region_abb in region_abbs:
            print("> {0}".format(region_abb))

            region = regions_dict[region_abb]

            arcpy.env.workspace = ProjectGDB

            region_mosaic = os.path.join(ProjectGDB, region_abb)

            crf = os.path.join( MOSAIC_DIRECTORY, "{0} {1}.crf".format(region.replace('-',' to '), DateCode))
            #print(crf)
            #print(region_mosaic)

            print(">-> arcpy.management.CopyRaster")
            arcpy.management.CopyRaster(region_mosaic,
                                        crf,
                                        '',
                                        None,
                                        "3.4e+38",
                                        "NONE",
                                        "NONE",
                                        '',
                                        "NONE",
                                        "NONE",
                                        "CRF",
                                        "NONE",
                                        "ALL_SLICES",
                                        "NO_TRANSPOSE")
            msg = arcpy.GetMessages()
            msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
            print(msg); del msg
            del crf


    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def main():
    pass

if __name__ == '__main__':
    # Use all of the cores on the machine.
    arcpy.env.parallelProcessingFactor = "100%"
    ##!!WARNING!!:::::::SET THE OVERWRITE TO ON - ANY ITEMS THAT GET SAVED WILL BE OVERWRITTEN
    arcpy.env.overwriteOutput = True

    print("add indexes to mosaics")


    regions_dict = {'AI' : 'Aleutian Islands',
                    'EBS' : 'Eastern Bering Sea',
                    'GOA' : 'Gulf of Alaska',
                    'GOM' : 'Gulf of Mexico',
                    'NEUS_F' : 'Northeast US Fall',
                    'NEUS_S' : 'Northeast US Spring',
                    'SEUS_SPR' : 'Southeast US Spring',
                    'SEUS_SUM' : 'Southeast US Summer',
                    'SEUS_FALL' : 'Southeast US Fall',
                    'WC_ANN' : 'West Coast Annual 2003-Present',
                    'WC_TRI' : 'West Coast Triennial 1977-2004',
                   }

    # Project related items
    Version = "March 2022"
    DateCode = "20220307"
    #DateCode = "20220301"
    #Version = "February 2022"
    #DateCode = "20220201"
    #Version = "March 2021"
    #DateCode = "20210301"
    ProjectName = "DisMap {0}".format(Version)

    BASE_DIRECTORY = os.path.dirname(os.path.realpath(__file__))
    BASE_DIRECTORY = os.path.join(BASE_DIRECTORY, Version)
    # print('BASE_DIRECTORY: ', BASE_DIRECTORY)

    # ###--->>> Software Environment Level
    #SoftwareEnvironmentLevel = ""
    #SoftwareEnvironmentLevel = "Dev"
    SoftwareEnvironmentLevel = "Test"

    ProjectGDB = os.path.join(BASE_DIRECTORY, "{0}.gdb".format(ProjectName + " " + SoftwareEnvironmentLevel))
    ANALYSIS_DIRECTORY = os.path.join(BASE_DIRECTORY, "Analysis Folder {0} {1}".format(Version, SoftwareEnvironmentLevel))
    MOSAIC_DIRECTORY = os.path.join(BASE_DIRECTORY, "Mosaic Folder {0} {1}".format(Version, SoftwareEnvironmentLevel))
    ScratchGDB = os.path.join(BASE_DIRECTORY, "Scratch {0} {1}".format(Version, SoftwareEnvironmentLevel), "scratch.gdb")
    ScratchFolder = os.path.join(BASE_DIRECTORY, "Scratch {0} {1}".format(Version, SoftwareEnvironmentLevel))

    arcpy.env.scratchWorkspace = ScratchGDB

    region_abbs = ['AI', 'EBS', 'GOA', 'GOM', 'NEUS_F', 'NEUS_S', 'SEUS_FALL', 'SEUS_SPR', 'SEUS_SUM', 'WC_ANN', 'WC_TRI',]
    #region_abbs = ['EBS', 'GOA', 'GOM', 'NEUS_F', 'NEUS_S', 'SEUS_FALL', 'SEUS_SPR', 'SEUS_SUM', 'WC_ANN', 'WC_TRI',]
    #region_abbs = ['EBS', 'GOA',]
    #region_abbs = ['GOM', 'NEUS_F', 'NEUS_S', 'SEUS_FALL', 'SEUS_SPR', 'SEUS_SUM', 'WC_ANN', 'WC_TRI',]
    #region_abbs = ['GOM', 'NEUS_F', 'NEUS_S', 'SEUS_FALL', 'SEUS_SPR', 'SEUS_SUM', 'WC_ANN', 'WC_TRI',]
    #region_abbs = ['AI']

    # main()

    #repairMosaicDatasetPaths()

    #calculateCellSizeRanges() # GOA

    #synchronizeMosaicDataset() # GOA

    #buildPyramidsandStatistics()

    #setMosaicDatasetProperties()

    #calculateField()

    #buildMultidimensionalInfo()

    #analyzeMosaicDataset()

    #copyRaster()


    print(">-> arcpy.management.Compact")
    arcpy.management.Compact(ProjectGDB)
    msg = arcpy.GetMessages()
    msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
    print(msg); del msg

##    region_species_image_name = os.path.join(ProjectGDB, 'RegionSpeciesYearImageName')
##    regions = unique_values(region_species_image_name, "OARegion")
##    print(regions)