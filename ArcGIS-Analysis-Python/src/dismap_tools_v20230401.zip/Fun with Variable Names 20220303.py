#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      john.f.kennedy
#
# Created:     02/03/2022
# Copyright:   (c) john.f.kennedy 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import arcpy
import string

def unique_values(table, field):  ##uses list comprehension
    with arcpy.da.SearchCursor(table, [field]) as cursor:
        return sorted({row[0] for row in cursor})

def unique_values_dict(table, fields):
    arcpy.management.SelectLayerByAttribute( table, "CLEAR_SELECTION" )
    with arcpy.da.SearchCursor(table, fields) as cursor:
        #return {row[0] : [row[1], row[2]] for row in cursor if row[0] not in ['NA', '']}
        return {row[0] : row[1] for row in cursor}


def main():
    punctuation_set = string.punctuation

    tb = r'D:\DisMAP\ArcGIS Analysis\February 2022\DisMap February 2022 Test.gdb\RegionSpeciesYearImageName'

    #species = unique_values(tb, "Species")
    species = unique_values_dict(tb, ["Species", "OARegion"])

    max_length = 0
    for specie in species:
        specie_set = set(specie)
        region = species[specie]

        if specie_set.intersection(punctuation_set):
            special_characters = " ".join(list(specie_set.intersection(punctuation_set)))
            varaible_name = " ".join(specie.replace(".","").replace("-"," ").replace("(","").replace(")","").replace('/','and').split())
            specie_length = len(specie)
            if specie_length > max_length:
                max_length = specie_length
            print("{0} {1} ({2})".format(region, specie, specie_length))
            print("\t Special Characters: {0}".format(special_characters))
            print("\t Variable Name: {0}".format(varaible_name))
    print(max_length)

if __name__ == '__main__':
    main()

##Sebastes sp. (miniatus / crocotulus) (36)
##	 Special Characters: ) ( . /
##	 Variable Name: Sebastes sp miniatus and crocotulus
##Geryon (Chaceon) quinquedens (28)
##	 Special Characters: ) (
##	 Variable Name: Geryon Chaceon quinquedens
##Chicoreus florifer-dilectus (27)
##	 Special Characters: -
##	 Variable Name: Chicoreus florifer dilectus