#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      john.f.kennedy
#
# Created:     30/01/2022
# Copyright:   (c) john.f.kennedy 2022
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import os
import arcpy
from arcpy import metadata as md
from time import time, localtime, strftime, sleep, gmtime
#from xml.dom import minidom
#import lxml.etree as etree
import xml.dom.minidom

def unique_values(table, field):  ##uses list comprehension
    with arcpy.da.SearchCursor(table, [field]) as cursor:
        return sorted({row[0] for row in cursor})


def main():
    try:
        print("main()")

        localKeys =  [key for key in locals().keys()]

        if localKeys:
            msg = "Local Keys: {0}".format(u", ".join(localKeys))
            print(msg); del msg
        del localKeys

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def saveInportTemplateMetadata():
    try:
        print("saveInportTemplateMetadata()")
        # Set a start time so that we can see how log things take
        start_time = time()

        # Set Workspace
        arcpy.env.workspace = ProjectGDB
        # Set Scratch Workspace
        arcpy.env.scratchWorkspace = ScratchGDB

        # Get the item's Metadata object
        mosaic_path = os.path.join(ProjectGDB, 'AI')
        mosaic_md = md.Metadata(mosaic_path)
        del mosaic_path

        msg = "Title: {0}".format(mosaic_md.title)
        print(msg); del msg

        # Save a copy of the item's metadata to an xml file as a backup.
        # This copy is for internal use only.
        target_copy_path = os.path.join(BASE_DIRECTORY, 'Inport Interpolated Biomass Metadata.xml')
        mosaic_md.saveAsXML(target_copy_path)

##        dom = xml.dom.minidom.parse(target_copy_path) # or xml.dom.minidom.parseString(xml_string)
##        pretty_xml_as_string = dom.toprettyxml()
##        del dom
##
##        #pretty_xml_as_string = '\n'.join([line for line in minidom.parse(target_copy_path) .toprettyxml(indent=" "*2, newl = '\n', encoding='UTF-8').split('\n') if line.strip()])
##        open(target_copy_path, 'w').write(pretty_xml_as_string)
##        del pretty_xml_as_string

        #x = etree.parse(target_copy_path)
        #print(etree.tostring(x, pretty_print=True))

        del target_copy_path

        # Save a version of the item's metadata without sensitive information
        # separately so it can be shared externally.
        #target_template_path = os.path.join(BASE_DIRECTORY, 'Inport Interpolated Biomass Metadata Template.xml')
        #mosaic_md.saveAsXML(target_template_path, 'TEMPLATE')
        #del target_template_path

        del mosaic_md

        # Get the item's Metadata object
        survey_locations_path = os.path.join(ProjectGDB, 'Aleutian_Islands_Survey_Locations')
        survey_locations_md = md.Metadata(survey_locations_path)
        del survey_locations_path

        msg = "Title: {0}".format(survey_locations_md.title)
        print(msg); del msg

        # Save a copy of the item's metadata to an xml file as a backup.
        # This copy is for internal use only.
        target_copy_path = os.path.join(BASE_DIRECTORY, 'Inport Survey Locations Metadata.xml')
        survey_locations_md.saveAsXML(target_copy_path)

##        dom = xml.dom.minidom.parse(target_copy_path) # or xml.dom.minidom.parseString(xml_string)
##        pretty_xml_as_string = dom.toprettyxml()
##        del dom
##
##        #pretty_xml_as_string = '\n'.join([line for line in minidom.parse(target_copy_path) .toprettyxml(indent=" "*2, newl = '\n', encoding='UTF-8').split('\n') if line.strip()])
##        open(target_copy_path, 'w').write(pretty_xml_as_string)
##        del pretty_xml_as_string

        del target_copy_path

        # Save a version of the item's metadata without sensitive information
        # separately so it can be shared externally.
        #target_template_path = os.path.join(BASE_DIRECTORY, 'Inport Survey Locations Metadata Template.xml')
        #survey_locations_md.saveAsXML(target_template_path, 'TEMPLATE')
        #del target_template_path

        del survey_locations_md

        # Get the item's Metadata object
        dismap_regions_path = os.path.join(ProjectGDB, 'DisMap_Regions')
        dismap_regions_md = md.Metadata(dismap_regions_path)
        del dismap_regions_path

        msg = "Title: {0}".format(dismap_regions_md.title)
        print(msg); del msg

        # Save a copy of the item's metadata to an xml file as a backup.
        # This copy is for internal use only.
        target_copy_path = os.path.join(BASE_DIRECTORY, 'Inport DisMap Regions Metadata.xml')
        dismap_regions_md.saveAsXML(target_copy_path)

##        dom = xml.dom.minidom.parse(target_copy_path) # or xml.dom.minidom.parseString(xml_string)
##        pretty_xml_as_string = dom.toprettyxml()
##        del dom
##
##        #pretty_xml_as_string = '\n'.join([line for line in minidom.parse(target_copy_path) .toprettyxml(indent=" "*2, newl = '\n', encoding='UTF-8').split('\n') if line.strip()])
##        open(target_copy_path, 'w').write(pretty_xml_as_string)
##        del pretty_xml_as_string

        del target_copy_path

        # Save a version of the item's metadata without sensitive information
        # separately so it can be shared externally.
        #target_template_path = os.path.join(BASE_DIRECTORY, 'Inport DisMap Regions Metadata Template.xml')
        #dismap_regions_md.saveAsXML(target_template_path, 'TEMPLATE')
        #del target_template_path

        del dismap_regions_md

        # Get the item's Metadata object
        indicators_path = os.path.join(ProjectGDB, 'Indicators')
        indicators_md = md.Metadata(indicators_path)
        del indicators_path

        msg = "Title: {0}".format(indicators_md.title)
        print(msg); del msg

        # Save a copy of the item's metadata to an xml file as a backup.
        # This copy is for internal use only.
        target_copy_path = os.path.join(BASE_DIRECTORY, 'InPort Indicators Table Metadata.xml')
        indicators_md.saveAsXML(target_copy_path)

##        dom = xml.dom.minidom.parse(target_copy_path) # or xml.dom.minidom.parseString(xml_string)
##        pretty_xml_as_string = dom.toprettyxml()
##        del dom
##
##        #pretty_xml_as_string = '\n'.join([line for line in minidom.parse(target_copy_path) .toprettyxml(indent=" "*2, newl = '\n', encoding='UTF-8').split('\n') if line.strip()])
##        open(target_copy_path, 'w').write(pretty_xml_as_string)
##        del pretty_xml_as_string

        del target_copy_path

        # Save a version of the item's metadata without sensitive information
        # separately so it can be shared externally.
        #target_template_path = os.path.join(BASE_DIRECTORY, 'InPort Indicators Table Metadata Template.xml')
        #indicators_md.saveAsXML(target_template_path, 'TEMPLATE')
        #del target_template_path

        del indicators_md

        # Elapsed time
        end_time = time()
        elapse_time =  end_time - start_time
        msg = u"Elapsed Time {0} (H:M:S)\n".format(strftime("%H:%M:%S", gmtime(elapse_time)))
        print(msg); del msg
        del start_time, end_time, elapse_time

        localKeys =  [key for key in locals().keys()]

        if localKeys:
            msg = "Local Keys: {0}".format(u", ".join(localKeys))
            print(msg); del msg
        del localKeys

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo

def importTemplateMetadata():
    try:
        print("importTemplateMetadata()")
        # Set a start time so that we can see how log things take
        start_time = time()

        # Set Workspace
        arcpy.env.workspace = ProjectGDB
        # Set Scratch Workspace
        arcpy.env.scratchWorkspace = ScratchGDB

        #mosaic_template_path = os.path.join(BASE_DIRECTORY, 'Inport Interpolated Biomass Metadata Template.xml')
        mosaic_template_path = os.path.join(BASE_DIRECTORY, 'Inport Interpolated Biomass Metadata.xml')

        #survey_locations_template_path = os.path.join(BASE_DIRECTORY, 'Inport Survey Locations Metadata Template.xml')
        survey_locations_template_path = os.path.join(BASE_DIRECTORY, 'Inport Survey Locations Metadata.xml')

        # Start looping over the table_name array as we go region by region.
        for table_name in table_names:
            # Assigning variables from items in the chosen table list
            #region_shape = table_name[0]
            #region_boundary = table_name[1]
            region_abb = table_name[2]
            region = table_name[3]
            csv_file = table_name[4]
            #region_georef = table_name[5]
            #region_contours = table_name[6]

            # Make Geodatabase friendly name
            region_name = region.replace('(','').replace(')','').replace('-','_to_').replace(' ', '_')

            # Write a message to the log file
            msg = "STARTING REGION {0} ON {1}".format(region, strftime("%a %b %d %I:%M:%S %p", localtime()))
            print(msg); del msg

            #print(region)
            #print(region_abb)
            #print(region_name)
            #print(csv_file)

            mosaic_md = md.Metadata(region_abb)

            msg = "\t Metadata Title: {0}".format(mosaic_md.title)
            print(msg); del msg

            # Import the standard-format metadata content to the target item
            if not mosaic_md.isReadOnly:
                # Synchronize the item's metadata now
                mosaic_md.synchronize('ALWAYS')
                mosaic_md.importMetadata(mosaic_template_path)
                mosaic_md.save()

            del mosaic_md

            survey_locations_md = md.Metadata("{0}_Survey_Locations".format(region_name))

            msg = "\t Metadata Title: {0}".format(survey_locations_md.title)
            print(msg); del msg

            # Import the standard-format metadata content to the target item
            if not survey_locations_md.isReadOnly:
                survey_locations_md.importMetadata(survey_locations_template_path)
                survey_locations_md.save()

            del survey_locations_md

            #Final benchmark for the region.
            msg = "ENDING REGION {} COMPLETED ON {}".format(region, strftime("%a %b %d %I:%M:%S %p", localtime()))
            print(msg); del msg

            del table_name, region_abb, region, csv_file, region_name

        # Elapsed time
        end_time = time()
        elapse_time =  end_time - start_time
        msg = u"Elapsed Time {0} (H:M:S)\n".format(strftime("%H:%M:%S", gmtime(elapse_time)))
        print(msg); del msg
        del start_time, end_time, elapse_time

        del mosaic_template_path, survey_locations_template_path

        localKeys =  [key for key in locals().keys()]

        if localKeys:
            msg = "Local Keys: {0}".format(u", ".join(localKeys))
            print(msg); del msg
        del localKeys

    except:
        import sys, traceback
        # Get the traceback object
        tb = sys.exc_info()[2]
        tbinfo = traceback.format_tb(tb)[0]
        # Concatenate information together concerning the error into a message string
        pymsg = "PYTHON ERRORS:\nTraceback info:\n" + tbinfo + "\nError Info:\n" + str(sys.exc_info()[1])
        print(pymsg)
        del pymsg, tb, tbinfo


if __name__ == '__main__':
    # Use all of the cores on the machine.
    arcpy.env.parallelProcessingFactor = "100%"
    ##!!WARNING!!:::::::SET THE OVERWRITE TO ON - ANY ITEMS THAT GET SAVED WILL BE OVERWRITTEN
    arcpy.env.overwriteOutput = True

    # Project related items
    Version = "March 2022"
    #Version = "March 2021"
    #DateCode = "20210301"
    #Version = "February 2022"
    DateCode = "20220307"
    #DateCode = "20220201"
    ProjectName = "DisMap {0}".format(Version)

    BASE_DIRECTORY = os.path.dirname(os.path.realpath(__file__))
    BASE_DIRECTORY = os.path.join(BASE_DIRECTORY, Version)
    # print('BASE_DIRECTORY: ', BASE_DIRECTORY)

    # ###--->>> Software Environment Level
    #SoftwareEnvironmentLevel = ""
    #SoftwareEnvironmentLevel = "Dev"
    SoftwareEnvironmentLevel = "Test"

    ProjectGDB = os.path.join(BASE_DIRECTORY, "{0}.gdb".format(ProjectName + " " + SoftwareEnvironmentLevel))
    ANALYSIS_DIRECTORY = os.path.join(BASE_DIRECTORY, "Analysis Folder {0} {1}".format(Version, SoftwareEnvironmentLevel))
    MOSAIC_DIRECTORY = os.path.join(BASE_DIRECTORY, "Mosaic Folder {0} {1}".format(Version, SoftwareEnvironmentLevel))
    ScratchGDB = os.path.join(BASE_DIRECTORY, "Scratch {0} {1}".format(Version, SoftwareEnvironmentLevel), "scratch.gdb")
    ScratchFolder = os.path.join(BASE_DIRECTORY, "Scratch {0} {1}".format(Version, SoftwareEnvironmentLevel))

    arcpy.env.scratchWorkspace = ScratchGDB

    table_names = [
                   [ 'AI_Shape', 'AI_Boundary','AI', 'Aleutian Islands', 'ai_csv', 'NAD_1983_2011_UTM_Zone_1N', 'contour_ai'],
                   [ 'EBS_Shape', 'EBS_Boundary','EBS', 'Eastern Bering Sea', 'ebs_csv', 'NAD_1983_2011_UTM_Zone_3N', 'contour_ebs'],
                   [ 'GOA_Shape', 'GOA_Boundary','GOA', 'Gulf of Alaska', 'goa_csv', 'NAD_1983_2011_UTM_Zone_5N', 'contour_goa'],

                   [ 'GOM_Shape', 'GOM_Boundary','GOM', 'Gulf of Mexico', 'gmex_csv', 'NAD_1983_2011_UTM_Zone_15N', 'contour_gom'],

                   [ 'NEUS_Fall_Shape', 'NEUS_Fall_Boundary','NEUS_F', 'Northeast US Fall', 'neusf_csv', 'NAD_1983_2011_UTM_Zone_18N', 'contour_neus'],
                   [ 'NEUS_Spring_Shape', 'NEUS_Spring_Boundary','NEUS_S', 'Northeast US Spring', 'neus_csv', 'NAD_1983_2011_UTM_Zone_18N', 'contour_neus'],


                   [ 'SEUS_Shape', 'SEUS_Boundary','SEUS_SPR', 'Southeast US Spring', 'seus_spr_csv', 'NAD_1983_2011_UTM_Zone_17N', 'contour_seus'],
                   [ 'SEUS_Shape', 'SEUS_Boundary','SEUS_SUM', 'Southeast US Summer', 'seus_sum_csv', 'NAD_1983_2011_UTM_Zone_17N', 'contour_seus'],
                   [ 'SEUS_Shape', 'SEUS_Boundary','SEUS_FALL', 'Southeast US Fall', 'seus_fal_csv', 'NAD_1983_2011_UTM_Zone_17N', 'contour_seus'],

                   [ 'WC_Ann_Shape', 'WC_Ann_Boundary','WC_ANN', 'West Coast Annual 2003-Present', 'wcann_csv', 'NAD_1983_2011_UTM_Zone_10N', 'contour_wc'],
                   [ 'WC_Tri_Shape', 'WC_Tri_Boundary','WC_TRI', 'West Coast Triennial 1977-2004', 'wctri_csv', 'NAD_1983_2011_UTM_Zone_10N', 'contour_wc']
                  ]

    #regions = ['Aleutian Islands', 'Eastern Bering Sea', 'Gulf of Alaska', 'Gulf of Mexico', 'Northeast US Fall',
    #           'Southeast US Fall', 'Northeast US Spring', 'Southeast US Spring', 'Southeast US Summer',
    #           'West Coast Annual 2003-Present', 'West Coast Triennial 1977-2004']

    # Set to True if we want to filter on certian one or more regions, else
    # False to process all regions
    FilterRegions = False

    # ###--->>> Use a list to filter on regions.
    # Below are lists used to
    # test different regions
    #selected_regions = ['AI', 'EBS', 'GOA', 'GOM', 'NEUS_F', 'NEUS_S', 'SEUS_FALL', 'SEUS_SPR', 'SEUS_SUM', 'WC_ANN', 'WC_TRI',]

    selected_regions = ['AI',]

    # Test if we are filtering on regions. If so, a new table_names list is
    # created with the selected regions remaining in the list
    if FilterRegions:
        # New table_names list of lists #-> https://stackoverflow.com/questions/21507319/python-list-comprehension-list-of-lists
        table_names = [[r for r in group] for group in table_names if group[2] in selected_regions]
    else:
        selected_regions = ['AI', 'EBS', 'GOA', 'GOM', 'NEUS_F', 'NEUS_S', 'SEUS_FALL', 'SEUS_SPR', 'SEUS_SUM', 'WC_ANN', 'WC_TRI',]

    # https://pro.arcgis.com/en/pro-app/2.8/arcpy/metadata/metadata-class.htm

    # Save Inport and Template Metadata XML files
    #saveInportTemplateMetadata()

    # Import Template Metadata XML files
    importTemplateMetadata()

    # Does nothing
    # main()


##    print(">-> arcpy.management.Compact")
##    arcpy.management.Compact(ProjectGDB)
##    msg = arcpy.GetMessages()
##    msg = ">->-> {0}".format(msg.replace('\n', '\n>->-> '))
##    print(msg); del msg
